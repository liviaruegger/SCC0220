Arquivo zip gerado em: 04/10/2021 21:26:23 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Módulo 1] Ordenação Aconchegante